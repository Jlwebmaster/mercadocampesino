<!DOCTYPE html>
<html lang="en">
<!-- Basic -->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Site Metas -->
    <title>Carrito</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <!-- Start Main Top -->
     <div class="main-top">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="custom-select-box">
                        
                    </div>
                    <div class="right-phone-box">
                        <p>Telefono :- <a href="#"> +506 2215-0414</a></p>
                    </div>
                    <div class="our-link">
                        <ul>
                            <li><a href="#"><i class="fa fa-user s_color"></i> </a></li>
                            <li><a href="#"><i class="fas fa-location-arrow"></i> </a></li>
                            <li><a href="#"><i class="fas fa-headset"></i> </a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="login-box">
                        <select id="basic" class="selectpicker show-tick form-control" data-placeholder="Sign In">
                            <option>Register Here</option>
                            <option>Sign In</option>
                        </select>
                    </div>
                    <div class="text-slid-box">
                        <div id="offer-box" class="carouselTicker">
                            <ul class="offer-box">
                                <li>
                                    <i class="fab fa-opencart"></i> Bienvenido a 
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Compre Bien
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Descuentos en todos los productos
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Productos de gran calidad
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Verduras frescas
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Vegetales Frescos
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> Compra en linea de forma segura
                                </li>
                                <li>
                                    <i class="fab fa-opencart"></i> 50% de descuento en produtos seleccionados 
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Main Top -->

    <!-- Start Main Top -->
    <header class="main-header">
        <!-- Start Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-default bootsnav">
            <div class="container">
                <!-- Start Header Navigation -->
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-menu" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                    <a class="navbar-brand" href="index.html"><img src="images/CompreBien.jpg" class="logo" alt=""></a>
                </div>
                <!-- End Header Navigation -->

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="navbar-menu">
                    <ul class="nav navbar-nav ml-auto" data-in="fadeInDown" data-out="fadeOutUp">
                        <li class="nav-item"><a class="nav-link" href="index.php">Inicio</a></li>
                        <li class="nav-item"><a class="nav-link" href="about.php">Nosotros</a></li>
                        
                        
                        <li class="nav-item"><a class="nav-link" href="contact-us.php">Contacto</a></li>
                    </ul>
                </div>
                <!-- /.navbar-collapse -->

                <!-- Start Atribute Navigation -->
                <div class="attr-nav">
                    <ul>
                       
					</a></li>
                    </ul>
                </div>
                <!-- End Atribute Navigation -->
            </div>
            <!-- Start Side Menu -->
            <div class="side">
                <a href="#" class="close-side"><i class="fa fa-times"></i></a>
                <li class="cart-box">
                    <ul class="cart-list">
                       
                    </ul>
                </li>
            </div>
            <!-- End Side Menu -->
        </nav>
        <!-- End Navigation -->
    </header>
    <!-- End Main Top -->

    <!-- Start Top Search -->
    <div class="top-search">
        <div class="container">
            <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-search"></i></span>
                <input type="text" class="form-control" placeholder="Search">
                <span class="input-group-addon close-search"><i class="fa fa-times"></i></span>
            </div>
        </div>
    </div>
    <!-- End Top Search -->

    <!-- Start All Title Box -->
    <div class="all-title-box">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2>Carrito</h2>
                    
                </div>
            </div>
        </div>
    </div>
    <!-- End All Title Box -->

    <!-- Start Cart  -->
    <div class="cart-box-main">
        <div class="container">
            <div class="row">
             <form method="post" action="">
                <div class="col-lg-12">
                    <div class="table-main table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Images</th>
                                    <th>Nombre del producto</th>
                                    <th>Precio</th>
                                    <th>Cantidad </th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
                                    
                                </a>
                                    </td>
                                    <td class="name-pr">
                                        <a href="#">
                                    Numero de pedido
                                </a>
                                    </td>
                                    <td class="price-pr">
                                        <p></p>
                                    </td>
                                    <td class="quantity-box"><input type="text" name="txtNumeroPD" placeholder="Número de pedido"></td>
                                    
                                        
                                    
                                </a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="images/img-pro-01.jpg" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                        <a href="#">
									Zanahoria
								</a>
                                    </td>
                                    <td class="price-pr">
                                        <p>₡ 1100 </p>
                                    </td>
                                    <td class="quantity-box">
                                        <input type="hidden" name="txtNumeroPDActualizar" value="<?php echo $NumeroPD; ?>">
                                        <input type="text" name="txtZanahoria" placeholder="Cantidad de Zanahorias" value="<?php echo isset($txtZanahoria) ? $txtZanahoria : ''; ?>">
                                    
                                        
									
								</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="images/img-pro-02.jpg" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                        <a href="#">
									Tomate
								</a>
                                    </td>
                                    <td class="price-pr">
                                        <p> ₡ 1200 </p>
                                    </td>
                                    <td class="quantity-box"> 
                                         <input type="hidden" name="txtNumeroPDActualizar" value="<?php echo $NumeroPD; ?>">

                                        <input type="text" name="txtTomate" placeholder="Cantidad de Tomates" value="<?php echo isset($txtTomate) ? $txtTomate : ''; ?>">
                                   
								</a>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="thumbnail-img">
                                        <a href="#">
									<img class="img-fluid" src="images/img-pro-03.jpg" alt="" />
								</a>
                                    </td>
                                    <td class="name-pr">
                                        <a href="#">
									Uvas verdes
								</a>
                                    </td>
                                    <td class="price-pr">
                                        <p> ₡ 1300 </p>
                                    </td>
                                    <td class="quantity-box"> 
                                      <input type="hidden" name="txtNumeroPDActualizar" value="<?php echo $NumeroPD; ?>">
                                      <input type="text" name="txtUva" placeholder="Cantidad de Uvas" value="<?php echo isset($txtUva) ? $txtUva : ''; ?>">

                                        <a href="#">
									<i class="fas fa-times"></i>
								</a>
                                    </td>

                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row my-5">
                <div class="col-lg-6 col-sm-6">
                    <div class="coupon-box">
                        <div class="input-group input-group-sm">
                        <h1>Total: </h1>
        
                        <input type="text" id="total" name="total" value="  ₡ 3800 " readonly>

                            <div class="input-group-append">
                                
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 col-sm-6">
                    <div class="update-box">
                      <input type="submit" name="btnIngresar" value="Ingresar">
                      <input type="submit" name="btnActualizar" value="Actualizar">
                      <input type="submit" name="btnCalcularTotal" onclick="myFunction()" value="Total">


                    </div>
                </div>
            </div>
         </form>

            <div class="row my-5">
                <div class="col-lg-8 col-sm-12"></div>
                <div class="col-lg-4 col-sm-12">
                    <div class="order-box">
                        

                        </div>
                        <hr></hr> </div>
                </div>
                


            </div>

        </div>
    </div>
    <!-- End Cart -->

    <!-- Start Instagram Feed  -->
    <div class="instagram-box">
        <div class="main-instagram owl-carousel owl-theme">
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-01.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-02.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-03.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-04.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-05.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-06.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-07.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-08.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-09.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="item">
                <div class="ins-inner-box">
                    <img src="images/instagram-img-05.jpg" alt="" />
                    <div class="hov-in">
                        <a href="#"><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Instagram Feed  -->


    <!-- Start Footer  -->
    
    </footer>
    <!-- End Footer  -->

    <!-- Start copyright  -->
    <div class="footer-copyright">
        <p class="footer-company">All Rights Reserved. &copy; 2018 <a href="#">ThewayShop</a> Design By :
            <a href="https://html.design/">html design</a></p>
    </div>
    <!-- End copyright  -->

    <a href="#" id="back-to-top" title="Back to top" style="display: none;">&uarr;</a>

    <!-- ALL JS FILES -->
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/jquery.superslides.min.js"></script>
    <script src="js/bootstrap-select.js"></script>
    <script src="js/inewsticker.js"></script>
    <script src="js/bootsnav.js."></script>
    <script src="js/images-loded.min.js"></script>
    <script src="js/isotope.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/baguetteBox.min.js"></script>
    <script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>




<?php

if (isset ($_POST ['btnIngresar'])) 
      {

       Ingresar_Pedido();
      }




 if (isset ($_POST ['btnActualizar'])) 
      {
        
        Actualizar_Pedido();

      }
if (isset ($_POST ['btnCalcularTotal'])) 
      {

        Total();
      }





 function Ingresar_Pedido()
      {

        $servidor = "localhost";
        $NombreUsuario = "root";
        $Clave = "";
        $BD = "pedidos";

        $conexion = new mysqli($servidor, $NombreUsuario, $Clave, $BD);

        if ($conexion->connect_error) {
        die("Conexión Fallida: " . $conexion->connect_error);
        }

     if (isset($_POST['btnIngresar'])) {
        $NumeroPD = $_POST['txtNumeroPD'];
        $Zanahoria = $_POST['txtZanahoria'];
        $Tomate = $_POST['txtTomate'];
        $Uva = $_POST['txtUva'];

        $sql = "INSERT INTO Pedidos (NumeroPD, zanahoria, tomate, uva) VALUES ('$NumeroPD', '$Zanahoria', '$Tomate', '$Uva')";

        if ($conexion->query($sql) === true) {
             echo "Se ingresaron los datos correctamente.";
           } else {
            echo "Error al ingresar datos: " . $conexion->error;
            }
        }

      }


function Actualizar_Pedido()
{
    $servidor = "localhost";
    $NombreUsuario = "root";
    $Clave = "";
    $BD = "pedidos";

    $conexion = new mysqli($servidor, $NombreUsuario, $Clave, $BD);

    if (isset($_POST['btnActualizar'])) {
        $NumeroPD = $_POST['txtNumeroPD'];
        $Zanahoria = $_POST['txtZanahoria'];
        $Tomate = $_POST['txtTomate'];
        $Uva = $_POST['txtUva'];

        $sql = "UPDATE Pedidos SET zanahoria = '$Zanahoria', tomate = '$Tomate', uva = '$Uva' WHERE NumeroPD = '$NumeroPD'";

        if ($conexion->query($sql) === true) {
            echo "<center>Datos Actualizados</center>";
        } else {
            die("Error al actualizar los datos: " . $conexion->error);
        }
    }
}

function Total()

{
    $servidor = "localhost";
    $NombreUsuario = "root";
    $Clave = "";
    $BD = "pedidos";

    $conexion = new mysqli($servidor, $NombreUsuario, $Clave, $BD);

    if ($conexion->connect_error) {
        die("Conexión Fallida: " . $conexion->connect_error);
    }

    $sql = "SELECT zanahoria, tomate, uva FROM Pedidos ORDER BY NumeroPD DESC LIMIT 1";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {
        $row = $resultado->fetch_assoc();
        $zanahoria = $row['zanahoria'];
        $tomate = $row['tomate'];
        $uva = $row['uva'];

        $total = ($zanahoria * 1100) + ($tomate * 1200) + ($uva * 1300);

        echo "Total del último pedido: ₡ " . $total;
        ?>


<?php
    } else {
        echo "No se encontraron pedidos en la base de datos.";
    }

    $conexion->close();

}


?>

</body>
</html>